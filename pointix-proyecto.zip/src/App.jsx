import { useState } from "react";

// ─── THEME ───────────────────────────────────────────────
const C = {
  bg: "#080810",
  card: "#0f0f1a",
  card2: "#131320",
  border: "#2a1f4a",
  neon: "#b347ff",
  neonDim: "#7c22cc",
  neonGlow: "rgba(179,71,255,0.25)",
  neonText: "#d580ff",
  accent: "#ff47c8",
  white: "#ffffff",
  gray: "#888",
  grayDark: "#333",
  orange: "#ff8c00",
  green: "#22C55E",
  red: "#ef4444",
};

// ─── MOCK DATA ────────────────────────────────────────────
const PRODUCTS_HOME = [
  { id:1, name:"High Quality Northface Bag Single Shoulder Fashion Trend Cross-Body Bag Unisex...", price:"PEN 0.25", daily:"34,337", growth:"73%", img:"🎒" },
  { id:2, name:"Portable Electric Sterilization Shoe Dryer UV Light Deodorizer Home Use...", price:"PEN 0.50", daily:"21,804", growth:"58%", img:"👟" },
  { id:3, name:"Wireless Bluetooth Earbuds TWS 5.3 HiFi Stereo Noise Cancelling Sports...", price:"PEN 1.20", daily:"18,992", growth:"45%", img:"🎧" },
  { id:4, name:"Smart Watch Fitness Tracker Heart Rate Monitor Waterproof Unisex Band...", price:"PEN 2.00", daily:"12,450", growth:"31%", img:"⌚" },
];

const ORDERS_DATA = [
  { id:"NMV44CD0ISC9", date:"2026-04-15 17:39:27", name:"Summer Short T shirt Quick Drying Sweat Wicking Sports Short Sleeve...", img:"👕", price:"PEN 49.04", commission:"PEN 14.70", diff:"PEN 0", status:"Completado" },
  { id:"MQPRTFUBSACL", date:"2026-04-15 17:39:18", name:"Seagate Backup plus Slim 5TB 4TB 2TB 1TB External 2.5\" Portable...", img:"💾", price:"PEN 71.02", commission:"PEN 21.30", diff:"PEN 0", status:"Completado" },
  { id:"KXVBN882LPQA", date:"2026-04-14 09:22:11", name:"Nike Air Max 270 React Running Shoes Lightweight Breathable...", img:"👟", price:"PEN 120.00", commission:"PEN 36.00", diff:"PEN 0", status:"Pendiente de envío" },
  { id:"ZRTY991MNCVB", date:"2026-04-13 15:10:05", name:"Apple AirPods Pro 2nd Gen Active Noise Cancellation Wireless...", img:"🎧", price:"PEN 380.00", commission:"PEN 114.00", diff:"PEN 0", status:"Pendiente de envío" },
];

const BANNERS = [
  { emoji:"🏬", label:"CENTRO COMERCIAL POINTIX" },
  { emoji:"🎁", label:"OFERTAS ESPECIALES VIP" },
  { emoji:"💎", label:"ZONA PREMIUM EXCLUSIVA" },
  { emoji:"🌟", label:"PRODUCTOS DESTACADOS" },
];

// ─── HELPERS ─────────────────────────────────────────────
function CircularScore({ value = 100 }) {
  const r = 26; const circ = 2 * Math.PI * r;
  const dash = (value / 100) * circ;
  return (
    <div style={{ position:"relative", width:68, height:68, flexShrink:0 }}>
      <svg width="68" height="68" style={{ transform:"rotate(-90deg)" }}>
        <circle cx="34" cy="34" r={r} fill="none" stroke="#1a0d2e" strokeWidth="6"/>
        <circle cx="34" cy="34" r={r} fill="none" stroke={C.neon} strokeWidth="6"
          strokeDasharray={`${dash} ${circ}`} strokeLinecap="round"/>
      </svg>
      <div style={{ position:"absolute", inset:0, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center" }}>
        <span style={{ fontSize:15, fontWeight:900, color:C.neon, lineHeight:1 }}>{value}</span>
      </div>
    </div>
  );
}

function Input({ label, type="text", value, onChange, placeholder }) {
  return (
    <div style={{ marginBottom:16 }}>
      <div style={{ fontSize:12, color:C.neonText, fontWeight:700, marginBottom:6, letterSpacing:0.5 }}>{label}</div>
      <input type={type} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder}
        style={{
          width:"100%", background:C.card2, border:`1.5px solid ${C.border}`,
          borderRadius:12, padding:"13px 16px", color:C.white,
          fontSize:14, outline:"none", boxSizing:"border-box",
          fontFamily:"inherit",
        }}
        onFocus={e=>e.target.style.borderColor=C.neon}
        onBlur={e=>e.target.style.borderColor=C.border}
      />
    </div>
  );
}

function NeonBtn({ children, onClick, outline=false, fullWidth=false, small=false }) {
  return (
    <button onClick={onClick} style={{
      width: fullWidth?"100%":"auto",
      background: outline ? "transparent" : `linear-gradient(135deg,${C.neon},${C.accent})`,
      border: outline ? `2px solid ${C.neon}` : "none",
      borderRadius:14, padding: small?"10px 18px":"15px 24px",
      color: outline ? C.neon : "#fff",
      fontWeight:800, fontSize: small?13:15, cursor:"pointer",
      display:"flex", alignItems:"center", justifyContent:"center", gap:8,
      boxShadow: outline ? "none" : `0 4px 20px ${C.neonGlow}`,
      fontFamily:"inherit",
    }}>{children}</button>
  );
}

// ─── SCREENS ─────────────────────────────────────────────

// LOGIN
function LoginScreen({ onLogin }) {
  const [mode, setMode] = useState("login"); // login | register
  const [field, setField] = useState("");
  const [pass, setPass] = useState("");
  const [confirm, setConfirm] = useState("");
  const [err, setErr] = useState("");

  const submit = () => {
    if (!field || !pass) { setErr("Completa todos los campos"); return; }
    if (mode==="register" && pass !== confirm) { setErr("Las contraseñas no coinciden"); return; }
    onLogin({ phone: field });
  };

  return (
    <div style={{ minHeight:"100vh", background:C.bg, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", padding:"24px 24px" }}>
      {/* Logo */}
      <div style={{ marginBottom:32, textAlign:"center" }}>
        <div style={{ fontSize:42, fontWeight:900, color:C.neon, letterSpacing:4, textShadow:`0 0 30px ${C.neon}` }}>POINTIX</div>
        <div style={{ fontSize:13, color:C.gray, marginTop:6, letterSpacing:1 }}>Tu plataforma de comisiones</div>
      </div>

      <div style={{ width:"100%", maxWidth:380, background:C.card, borderRadius:24, padding:"28px 24px", border:`1px solid ${C.border}` }}>
        {/* tabs */}
        <div style={{ display:"flex", background:C.card2, borderRadius:12, padding:4, marginBottom:24 }}>
          {["login","register"].map(m=>(
            <button key={m} onClick={()=>{setMode(m);setErr("");}} style={{
              flex:1, padding:"10px", border:"none", borderRadius:10, cursor:"pointer",
              background: mode===m ? `linear-gradient(135deg,${C.neon},${C.accent})` : "transparent",
              color: mode===m ? "#fff" : C.gray, fontWeight:800, fontSize:13, fontFamily:"inherit",
            }}>{m==="login"?"Iniciar sesión":"Registrarse"}</button>
          ))}
        </div>

        <Input label="Teléfono o correo electrónico" value={field} onChange={setField} placeholder="+51 999 000 000 o correo"/>
        <Input label="Contraseña" type="password" value={pass} onChange={setPass} placeholder="••••••••"/>
        {mode==="register" && <Input label="Confirmar contraseña" type="password" value={confirm} onChange={setConfirm} placeholder="••••••••"/>}

        {err && <div style={{ color:C.red, fontSize:12, marginBottom:12, fontWeight:600 }}>⚠️ {err}</div>}

        {mode==="login" && (
          <div style={{ textAlign:"right", marginBottom:16 }}>
            <span style={{ fontSize:12, color:C.neonText, cursor:"pointer" }}>¿Olvidaste tu contraseña?</span>
          </div>
        )}

        <NeonBtn fullWidth onClick={submit}>{mode==="login"?"Ingresar →":"Crear cuenta →"}</NeonBtn>

        <div style={{ textAlign:"center", marginTop:16, fontSize:12, color:C.gray }}>
          {mode==="login" ? "¿No tienes cuenta? " : "¿Ya tienes cuenta? "}
          <span style={{ color:C.neonText, fontWeight:700, cursor:"pointer" }} onClick={()=>{setMode(mode==="login"?"register":"login");setErr("");}}>
            {mode==="login"?"Regístrate":"Inicia sesión"}
          </span>
        </div>
      </div>

      <div style={{ marginTop:24, fontSize:11, color:"#444", textAlign:"center", maxWidth:320 }}>
        Al continuar aceptas los Términos y Condiciones y la Política de Privacidad de POINTIX
      </div>
    </div>
  );
}

// HOME
function HomeTab() {
  const [bannerIdx, setBannerIdx] = useState(0);
  const [copied, setCopied] = useState(false);

  return (
    <div>
      {/* scroll ticker */}
      <div style={{ background:C.card2, borderBottom:`1px solid ${C.border}`, padding:"8px 14px", display:"flex", alignItems:"center", gap:8, overflow:"hidden" }}>
        <span style={{ fontSize:14 }}>📢</span>
        <span style={{ fontSize:12, color:C.gray, whiteSpace:"nowrap" }}>
          <span style={{ color:C.neon }}>8kzvDipf</span> Retirar: 47,181.95 PEN 🔴 Hora: 06-06 &nbsp;&nbsp;&nbsp;
          <span style={{ color:C.neon }}>Mx9pLqRt</span> Retirar: 12,540.00 PEN 🔴 Hora: 06-05
        </span>
      </div>

      {/* Banner */}
      <div style={{ padding:"12px 14px 10px" }}>
        <div style={{ background:C.card, borderRadius:18, overflow:"hidden", height:180, position:"relative", border:`1px solid ${C.border}` }}>
          <div style={{ height:"100%", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center",
            background:`linear-gradient(135deg,#0d0020 0%,#1a0035 100%)`, gap:8 }}>
            <div style={{ fontSize:52 }}>{BANNERS[bannerIdx].emoji}</div>
            <div style={{ fontSize:16, fontWeight:900, color:"#fff", letterSpacing:2, textAlign:"center", padding:"0 20px" }}>{BANNERS[bannerIdx].label}</div>
            <div style={{ background:`linear-gradient(135deg,${C.neon},${C.accent})`, color:"#fff", borderRadius:99, padding:"4px 16px", fontSize:12, fontWeight:800 }}>Ver ofertas →</div>
          </div>
          <div style={{ position:"absolute", bottom:10, left:0, right:0, display:"flex", justifyContent:"center", gap:5 }}>
            {BANNERS.map((_,i)=>(
              <button key={i} onClick={()=>setBannerIdx(i)} style={{ width:i===bannerIdx?18:6, height:6, borderRadius:99, background:i===bannerIdx?C.neon:C.grayDark, border:"none", cursor:"pointer", padding:0, transition:"width 0.3s" }}/>
            ))}
          </div>
        </div>
      </div>

      {/* User card */}
      <div style={{ padding:"0 14px 12px" }}>
        <div style={{ background:`linear-gradient(135deg,#0d0020,#1a0035)`, borderRadius:18, padding:"18px", border:`1px solid ${C.border}`, display:"flex", alignItems:"center", gap:14 }}>
          <div style={{ width:62, height:62, borderRadius:"50%", background:"#1a0035", border:`2px solid ${C.neon}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:30, flexShrink:0, boxShadow:`0 0 16px ${C.neonGlow}` }}>👤</div>
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ fontSize:16, fontWeight:800, color:"#fff" }}>914189307</div>
            <div style={{ display:"flex", alignItems:"center", gap:6, marginTop:3 }}>
              <span style={{ fontSize:12, color:C.gray }}>ID 260692110</span>
              <button onClick={()=>setCopied(true)} style={{ background:"none", border:"none", cursor:"pointer", fontSize:14, color:copied?C.neon:"#555", padding:0 }}>⧉</button>
            </div>
            <div style={{ fontSize:22, fontWeight:900, color:C.neon, marginTop:6, display:"flex", alignItems:"center", gap:6, textShadow:`0 0 12px ${C.neon}` }}>
              🟣 PEN 4,412.76
            </div>
          </div>
          <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:4 }}>
            <CircularScore value={100}/>
            <div style={{ fontSize:10, color:C.gray, textAlign:"center", lineHeight:1.3 }}>Puntuación<br/>de crédito</div>
          </div>
        </div>
      </div>

      {/* Recargar / Retirar */}
      <div style={{ padding:"0 14px 16px", display:"flex", gap:12 }}>
        <NeonBtn fullWidth onClick={()=>{}}><span>💰</span> Recargar</NeonBtn>
        <NeonBtn fullWidth outline onClick={()=>{}}><span>⬆️</span> Retirar</NeonBtn>
      </div>

      {/* Products */}
      <div style={{ padding:"0 14px" }}>
        <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:12 }}>
          <div style={{ width:4, height:20, background:`linear-gradient(${C.neon},${C.accent})`, borderRadius:99 }}/>
          <span style={{ fontSize:15, fontWeight:800, color:"#fff" }}>Productos más vendidos de hoy</span>
        </div>
        <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
          {PRODUCTS_HOME.map(p=>(
            <div key={p.id} style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:16, padding:"14px", display:"flex", gap:12, alignItems:"center" }}>
              <div style={{ width:78, height:78, borderRadius:12, flexShrink:0, background:C.card2, display:"flex", alignItems:"center", justifyContent:"center", fontSize:36, border:`1px solid ${C.border}` }}>{p.img}</div>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:12, color:"#ccc", fontWeight:600, display:"-webkit-box", WebkitLineClamp:2, WebkitBoxOrient:"vertical", overflow:"hidden", lineHeight:1.4 }}>{p.name}</div>
                <div style={{ marginTop:8, display:"flex", justifyContent:"space-between", alignItems:"flex-end" }}>
                  <div>
                    {["Precio:","Ventas diarias:","Tasa de crecimiento:"].map(l=>(
                      <div key={l} style={{ fontSize:11, color:"#555", marginTop:2 }}>{l}</div>
                    ))}
                  </div>
                  <div style={{ textAlign:"right" }}>
                    <div style={{ fontSize:13, fontWeight:800, color:"#fff" }}>{p.price}</div>
                    <div style={{ fontSize:12, color:C.neon, fontWeight:700, marginTop:1 }}>{p.daily}</div>
                    <div style={{ fontSize:12, color:C.neon, fontWeight:700, marginTop:1 }}>{p.growth}</div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// VIP
function VipTab() {
  const levels = [
    { name:"VIP 1", req:"0 – 999 pts", margin:"1.5%", tasks:10, icon:"🥉", color:"#cd7f32" },
    { name:"VIP 2", req:"1,000 – 4,999 pts", margin:"2.5%", tasks:20, icon:"🥈", color:"#aaa" },
    { name:"VIP 3", req:"5,000 – 9,999 pts", margin:"3.4%", tasks:36, icon:"🥇", color:"#ffd700" },
    { name:"VIP 4", req:"10,000 – 49,999 pts", margin:"5.0%", tasks:60, icon:"💎", color:C.neon },
    { name:"VIP 5", req:"50,000+ pts", margin:"8.0%", tasks:100, icon:"👑", color:C.accent },
  ];
  return (
    <div style={{ padding:"20px 14px" }}>
      <div style={{ fontSize:15, fontWeight:800, color:C.neonText, marginBottom:16 }}>👑 Niveles VIP</div>
      {levels.map(v=>(
        <div key={v.name} style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:16, padding:"16px", marginBottom:10, display:"flex", gap:14, alignItems:"center" }}>
          <span style={{ fontSize:32 }}>{v.icon}</span>
          <div style={{ flex:1 }}>
            <div style={{ fontWeight:800, color:v.color, fontSize:15 }}>{v.name}</div>
            <div style={{ fontSize:12, color:C.gray, marginTop:2 }}>{v.req}</div>
            <div style={{ display:"flex", gap:16, marginTop:6 }}>
              <span style={{ fontSize:11, color:C.neonText }}>📈 Margen: <b>{v.margin}</b></span>
              <span style={{ fontSize:11, color:C.neonText }}>📋 Tareas: <b>{v.tasks}</b></span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

// TRANSACCIONES
function TransaccionesTab() {
  return (
    <div style={{ padding:"14px 14px" }}>
      {/* Saldo card */}
      <div style={{ background:`linear-gradient(135deg,#0d0020,#1a0035)`, borderRadius:18, padding:"20px", border:`1px solid ${C.border}`, marginBottom:14, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
        <div>
          <div style={{ fontSize:12, color:C.gray, marginBottom:4 }}>Saldo de la cuenta</div>
          <div style={{ fontSize:28, fontWeight:900, color:C.neon, textShadow:`0 0 16px ${C.neon}`, display:"flex", alignItems:"center", gap:6 }}>🟣 PEN 4,412.76</div>
          <div style={{ fontSize:12, color:C.gray, marginTop:6 }}>Ingresos acumulados</div>
          <div style={{ fontSize:16, fontWeight:800, color:C.neonText }}>PEN 2,281.76</div>
        </div>
        <div style={{ fontSize:48, opacity:0.3 }}>👜</div>
      </div>

      {/* Recargar / Retirar */}
      <div style={{ display:"flex", gap:12, marginBottom:14 }}>
        <NeonBtn fullWidth onClick={()=>{}}><span>💰</span> Recargar</NeonBtn>
        <NeonBtn fullWidth outline onClick={()=>{}}><span>⬆️</span> Retirar</NeonBtn>
      </div>

      {/* Tarea activa */}
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:18, padding:"18px", marginBottom:14 }}>
        <div style={{ display:"flex", justifyContent:"space-between", marginBottom:10 }}>
          <span style={{ fontSize:13, color:C.gray }}>Nombre del producto</span>
          <span style={{ fontSize:13, color:"#fff", fontWeight:700 }}>50 Styles of Tinplate S...</span>
        </div>
        {[
          ["Progreso de la tarea","(1/1)"],
          ["Precio del pedido","PEN 7,938.76"],
          ["Comisión","PEN 3,334.27"],
          ["Diferencia de precio","PEN 3,526"],
          ["Estado del pedido","Pendiente de envío"],
        ].map(([k,v])=>(
          <div key={k} style={{ display:"flex", justifyContent:"space-between", padding:"8px 0", borderTop:`1px solid ${C.grayDark}` }}>
            <span style={{ fontSize:12, color:C.gray }}>{k}</span>
            <span style={{ fontSize:12, color:"#fff", fontWeight:600 }}>{v}</span>
          </div>
        ))}
        <div style={{ marginTop:14 }}>
          <NeonBtn fullWidth onClick={()=>{}}>Enviar ahora</NeonBtn>
        </div>
      </div>

      {/* Stats */}
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:18, padding:"18px" }}>
        <div style={{ display:"flex", marginBottom:16 }}>
          <div style={{ flex:1, textAlign:"center" }}>
            <div style={{ fontSize:32, fontWeight:900, color:"#fff" }}>36</div>
            <div style={{ fontSize:11, color:C.gray, marginTop:4 }}>Número total de tareas</div>
          </div>
          <div style={{ width:1, background:C.border }}/>
          <div style={{ flex:1, textAlign:"center" }}>
            <div style={{ fontSize:32, fontWeight:900, color:"#fff" }}>32</div>
            <div style={{ fontSize:11, color:C.gray, marginTop:4 }}>Número de tareas completadas</div>
          </div>
        </div>
        <div style={{ borderTop:`1px solid ${C.border}`, paddingTop:12 }}>
          {[["Margen de ganancia","3.4%"],["Nivel de membresía","VIP3"]].map(([k,v])=>(
            <div key={k} style={{ display:"flex", justifyContent:"space-between", padding:"6px 0" }}>
              <span style={{ fontSize:13, color:C.gray }}>{k}</span>
              <span style={{ fontSize:13, color:C.neon, fontWeight:700 }}>{v}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// PEDIDOS
function PedidosTab() {
  const [filter, setFilter] = useState("Todos");
  const filters = ["Todos","Pendiente de envío","Completado"];
  const filtered = filter==="Todos" ? ORDERS_DATA : ORDERS_DATA.filter(o=>o.status===filter);
  return (
    <div style={{ padding:"14px 14px" }}>
      {/* filter pills */}
      <div style={{ background:C.card, borderRadius:14, padding:4, display:"flex", marginBottom:16, border:`1px solid ${C.border}` }}>
        {filters.map(f=>(
          <button key={f} onClick={()=>setFilter(f)} style={{
            flex:1, padding:"9px 4px", border:"none", borderRadius:11, cursor:"pointer",
            background: filter===f ? `linear-gradient(135deg,${C.neon},${C.accent})` : "transparent",
            color: filter===f ? "#fff" : C.gray, fontWeight:700, fontSize:11, fontFamily:"inherit",
          }}>{f}</button>
        ))}
      </div>

      {filtered.length===0 && <div style={{ textAlign:"center", color:C.gray, marginTop:40 }}>No hay pedidos</div>}

      {filtered.map(o=>(
        <div key={o.id} style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:18, padding:"16px", marginBottom:12 }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:10 }}>
            <span style={{ fontSize:12, color:C.gray }}>{o.date}</span>
            <span style={{ background: o.status==="Completado" ? "#0d2a0d" : "#1a1a00", color: o.status==="Completado" ? C.green : "#ffd700", borderRadius:99, padding:"3px 12px", fontSize:11, fontWeight:700 }}>{o.status}</span>
          </div>
          <div style={{ borderTop:`1px dashed ${C.border}`, paddingTop:12, display:"flex", gap:12, alignItems:"flex-start", marginBottom:12 }}>
            <div style={{ width:60, height:60, borderRadius:10, background:C.card2, display:"flex", alignItems:"center", justifyContent:"center", fontSize:28, flexShrink:0, border:`1px solid ${C.border}` }}>{o.img}</div>
            <div style={{ fontSize:12, color:"#ccc", lineHeight:1.5 }}>{o.name}</div>
          </div>
          {[["Número de pedido",o.id,"#fff"],["Precio del pedido",o.price,"#fff"],["Comisión",o.commission,C.orange],["Diferencia de precio",o.diff,"#fff"]].map(([k,v,col])=>(
            <div key={k} style={{ display:"flex", justifyContent:"space-between", padding:"5px 0", borderTop:`1px solid ${C.grayDark}` }}>
              <span style={{ fontSize:12, color:C.gray }}>{k}</span>
              <span style={{ fontSize:12, color:col, fontWeight:700 }}>{v}</span>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

// MI CUENTA — sub-screens
function CardForm({ onBack }) {
  const [type, setType] = useState("bank");
  const [bank, setBank] = useState(""); const [account, setAccount] = useState("");
  const [holder, setHolder] = useState(""); const [card, setCard] = useState("");
  const [saved, setSaved] = useState(false);
  const save = () => { if(!holder||(type==="bank"?!account:!card)) return; setSaved(true); setTimeout(()=>setSaved(false),2000); };
  return (
    <div style={{ padding:"20px 14px" }}>
      <button onClick={onBack} style={{ background:"none", border:"none", color:C.neonText, fontSize:14, fontWeight:700, cursor:"pointer", marginBottom:16, display:"flex", alignItems:"center", gap:6 }}>← Volver</button>
      <div style={{ fontSize:15, fontWeight:800, color:C.neonText, marginBottom:16 }}>💳 Agregar tarjeta / cuenta bancaria</div>
      <div style={{ display:"flex", gap:8, marginBottom:20 }}>
        {["bank","card"].map(t=>(
          <button key={t} onClick={()=>setType(t)} style={{ flex:1, padding:"10px", border:`1.5px solid ${type===t?C.neon:C.border}`, borderRadius:12, background:type===t?C.card2:C.card, color:type===t?C.neon:C.gray, fontWeight:700, fontSize:13, cursor:"pointer", fontFamily:"inherit" }}>
            {t==="bank"?"🏦 Cuenta bancaria":"💳 Tarjeta"}
          </button>
        ))}
      </div>
      <Input label="Titular de la cuenta" value={holder} onChange={setHolder} placeholder="Nombre completo"/>
      {type==="bank" ? (
        <>
          <Input label="Banco" value={bank} onChange={setBank} placeholder="Ej: BCP, Interbank, BBVA..."/>
          <Input label="Número de cuenta" value={account} onChange={setAccount} placeholder="Número de cuenta bancaria"/>
        </>
      ) : (
        <Input label="Número de tarjeta" value={card} onChange={setCard} placeholder="0000 0000 0000 0000"/>
      )}
      {saved && <div style={{ color:C.green, fontWeight:700, marginBottom:12, fontSize:13 }}>✅ Guardado correctamente</div>}
      <NeonBtn fullWidth onClick={save}>Guardar</NeonBtn>
    </div>
  );
}

function InfoScreen({ onBack }) {
  return (
    <div style={{ padding:"20px 14px" }}>
      <button onClick={onBack} style={{ background:"none", border:"none", color:C.neonText, fontSize:14, fontWeight:700, cursor:"pointer", marginBottom:16, display:"flex", alignItems:"center", gap:6 }}>← Volver</button>
      <div style={{ fontSize:15, fontWeight:800, color:C.neonText, marginBottom:16 }}>ℹ️ Sobre POINTIX</div>
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:18, padding:"20px", marginBottom:14 }}>
        <div style={{ fontSize:22, fontWeight:900, color:C.neon, letterSpacing:2, marginBottom:10, textShadow:`0 0 12px ${C.neon}` }}>POINTIX</div>
        <div style={{ fontSize:13, color:"#ccc", lineHeight:1.7 }}>
          POINTIX es una plataforma digital de comercio electrónico y comisiones que conecta a vendedores con compradores en toda Latinoamérica. Nuestra misión es generar ingresos reales para nuestros usuarios a través de un sistema transparente de tareas y comisiones.{"\n\n"}
          Con POINTIX puedes ganar comisiones completando tareas de compra/venta, retirar tus ganancias cuando quieras y escalar tu nivel VIP para obtener mejores márgenes.
        </div>
      </div>
      <div style={{ fontSize:14, fontWeight:800, color:C.neonText, marginBottom:10 }}>📋 Reglas y condiciones</div>
      {[
        "1. Cada usuario debe completar las tareas asignadas en el orden indicado para recibir su comisión.",
        "2. Los retiros están disponibles una vez que el saldo mínimo de PEN 10.00 sea alcanzado.",
        "3. Está prohibido crear múltiples cuentas. Las cuentas duplicadas serán suspendidas.",
        "4. Las comisiones se calculan según el nivel VIP activo del usuario al momento de la tarea.",
        "5. POINTIX no se hace responsable por errores en datos bancarios ingresados por el usuario.",
        "6. El usuario debe completar su perfil y verificar su cuenta para activar retiros.",
        "7. Cualquier intento de fraude o manipulación resultará en la suspensión permanente.",
        "8. El soporte al cliente está disponible de lunes a sábado de 9am a 6pm.",
      ].map((r,i)=>(
        <div key={i} style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:12, padding:"12px 14px", marginBottom:8, fontSize:12, color:"#bbb", lineHeight:1.6 }}>{r}</div>
      ))}
    </div>
  );
}

function PersonalInfoScreen({ onBack }) {
  const [name, setName] = useState("María García");
  const [email, setEmail] = useState("maria@email.com");
  const [phone, setPhone] = useState("914189307");
  const [saved, setSaved] = useState(false);
  return (
    <div style={{ padding:"20px 14px" }}>
      <button onClick={onBack} style={{ background:"none", border:"none", color:C.neonText, fontSize:14, fontWeight:700, cursor:"pointer", marginBottom:16, display:"flex", alignItems:"center", gap:6 }}>← Volver</button>
      <div style={{ fontSize:15, fontWeight:800, color:C.neonText, marginBottom:16 }}>👤 Información personal</div>
      <Input label="Nombre completo" value={name} onChange={setName} placeholder="Tu nombre"/>
      <Input label="Correo electrónico" value={email} onChange={setEmail} placeholder="correo@email.com"/>
      <Input label="Teléfono" value={phone} onChange={setPhone} placeholder="+51 999 000 000"/>
      {saved && <div style={{ color:C.green, fontWeight:700, marginBottom:12, fontSize:13 }}>✅ Guardado</div>}
      <NeonBtn fullWidth onClick={()=>{setSaved(true);setTimeout(()=>setSaved(false),2000);}}>Guardar cambios</NeonBtn>
    </div>
  );
}

function ChangePassScreen({ onBack }) {
  const [cur, setCur] = useState(""); const [nw, setNw] = useState(""); const [conf, setConf] = useState("");
  const [msg, setMsg] = useState("");
  const save = () => { if(!cur||!nw||!conf){setMsg("error:Completa todos los campos");return;} if(nw!==conf){setMsg("error:Las contraseñas no coinciden");return;} setMsg("ok:Contraseña actualizada"); };
  const isErr = msg.startsWith("error:"); const isOk = msg.startsWith("ok:");
  return (
    <div style={{ padding:"20px 14px" }}>
      <button onClick={onBack} style={{ background:"none", border:"none", color:C.neonText, fontSize:14, fontWeight:700, cursor:"pointer", marginBottom:16, display:"flex", alignItems:"center", gap:6 }}>← Volver</button>
      <div style={{ fontSize:15, fontWeight:800, color:C.neonText, marginBottom:16 }}>🔒 Cambiar contraseña</div>
      <Input label="Contraseña actual" type="password" value={cur} onChange={setCur} placeholder="••••••••"/>
      <Input label="Nueva contraseña" type="password" value={nw} onChange={setNw} placeholder="••••••••"/>
      <Input label="Confirmar nueva contraseña" type="password" value={conf} onChange={setConf} placeholder="••••••••"/>
      {msg && <div style={{ color:isErr?C.red:C.green, fontWeight:700, marginBottom:12, fontSize:13 }}>{isErr?"⚠️":"✅"} {msg.split(":")[1]}</div>}
      <NeonBtn fullWidth onClick={save}>Actualizar contraseña</NeonBtn>
    </div>
  );
}

function MiCuentaTab({ onLogout }) {
  const [screen, setScreen] = useState("main"); // main|personal|card|pass|info
  if (screen==="card") return <CardForm onBack={()=>setScreen("main")}/>;
  if (screen==="info") return <InfoScreen onBack={()=>setScreen("main")}/>;
  if (screen==="personal") return <PersonalInfoScreen onBack={()=>setScreen("main")}/>;
  if (screen==="pass") return <ChangePassScreen onBack={()=>setScreen("main")}/>;

  const items = [
    { icon:"👤", label:"Información personal", key:"personal" },
    { icon:"💳", label:"Tarjetas personales", key:"card" },
    { icon:"📊", label:"Detalles de fondos", key:"funds" },
    { icon:"🔒", label:"Cambiar contraseña", key:"pass" },
    { icon:"🎧", label:"Servicio al cliente", key:"support" },
    { icon:"ℹ️", label:"Sobre POINTIX / Reglas", key:"info" },
  ];
  return (
    <div style={{ padding:"14px 14px" }}>
      {/* profile card */}
      <div style={{ background:`linear-gradient(135deg,#0d0020,#1a0035)`, borderRadius:18, padding:"18px 16px", border:`1px solid ${C.border}`, marginBottom:14 }}>
        <div style={{ display:"flex", alignItems:"center", gap:14, marginBottom:14 }}>
          <div style={{ width:58, height:58, borderRadius:"50%", background:"#1a0035", border:`2px solid ${C.neon}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:28, boxShadow:`0 0 16px ${C.neonGlow}` }}>👤</div>
          <div>
            <div style={{ fontSize:16, fontWeight:800, color:"#fff" }}>María García</div>
            <div style={{ fontSize:12, color:C.gray, marginTop:2 }}>914189307</div>
            <div style={{ display:"inline-block", background:`linear-gradient(135deg,${C.neon},${C.accent})`, color:"#fff", borderRadius:99, padding:"2px 10px", fontSize:11, fontWeight:800, marginTop:6 }}>⭐ VIP3</div>
          </div>
        </div>
        <div style={{ display:"flex", gap:12 }}>
          <NeonBtn fullWidth onClick={()=>{}}><span>💰</span> Recargar</NeonBtn>
          <NeonBtn fullWidth outline onClick={()=>{}}><span>⬆️</span> Retirar</NeonBtn>
        </div>
      </div>

      {/* city banner */}
      <div style={{ background:`linear-gradient(135deg,#0d0020,#1a0035)`, borderRadius:16, height:90, marginBottom:14, display:"flex", alignItems:"center", justifyContent:"center", border:`1px solid ${C.border}`, overflow:"hidden", position:"relative" }}>
        <div style={{ fontSize:48, opacity:0.5 }}>🌆</div>
        <div style={{ position:"absolute", bottom:8, left:14, fontSize:11, color:C.neonText, fontWeight:700, letterSpacing:1 }}>POINTIX — Tu ciudad, tus ganancias</div>
      </div>

      {/* menu items */}
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:18, overflow:"hidden" }}>
        {items.map((item,i)=>(
          <button key={item.key} onClick={()=>setScreen(item.key)} style={{
            width:"100%", background:"transparent", border:"none", borderBottom: i<items.length-1?`1px solid ${C.grayDark}`:"none",
            padding:"16px 18px", display:"flex", alignItems:"center", gap:14, cursor:"pointer", textAlign:"left",
          }}>
            <span style={{ fontSize:20, width:28, textAlign:"center" }}>{item.icon}</span>
            <span style={{ flex:1, fontSize:14, fontWeight:600, color:"#ddd" }}>{item.label}</span>
            <span style={{ color:C.grayDark, fontSize:18 }}>›</span>
          </button>
        ))}
      </div>

      <button onClick={onLogout} style={{ width:"100%", background:C.card, border:`1px solid ${C.border}`, borderRadius:14, padding:"16px", marginTop:12, color:C.gray, fontSize:14, fontWeight:700, cursor:"pointer", fontFamily:"inherit" }}>
        Cerrar sesión
      </button>
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────
const TABS = [
  { label:"Inicio", icon:"🏠" },
  { label:"VIP", icon:"👑" },
  { label:"Transacciones", icon:"☰" },
  { label:"Pedidos", icon:"📋" },
  { label:"Mi cuenta", icon:"👤" },
];

export default function Pointix() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [activeTab, setActiveTab] = useState(0);

  if (!loggedIn) return <LoginScreen onLogin={()=>setLoggedIn(true)}/>;

  const renderTab = () => {
    if (activeTab===0) return <HomeTab/>;
    if (activeTab===1) return <VipTab/>;
    if (activeTab===2) return <TransaccionesTab/>;
    if (activeTab===3) return <PedidosTab/>;
    if (activeTab===4) return <MiCuentaTab onLogout={()=>setLoggedIn(false)}/>;
  };

  return (
    <div style={{ minHeight:"100vh", background:C.bg, display:"flex", justifyContent:"center", fontFamily:"'Nunito','Segoe UI',sans-serif" }}>
      <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap" rel="stylesheet"/>
      <div style={{ width:"100%", maxWidth:420, minHeight:"100vh", background:C.bg, position:"relative", paddingBottom:80, overflowX:"hidden" }}>

        {/* TOP BAR */}
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"44px 16px 10px", background:`linear-gradient(180deg,#0d0020 0%,${C.bg} 100%)` }}>
          <span style={{ fontSize:26, fontWeight:900, color:C.neon, letterSpacing:4, textShadow:`0 0 20px ${C.neon}` }}>POINTIX</span>
          <div style={{ display:"flex", gap:8 }}>
            <button style={{ background:C.card2, border:`1px solid ${C.border}`, borderRadius:"50%", width:36, height:36, color:C.neonText, fontSize:16, cursor:"pointer" }}>🔔</button>
            <button style={{ background:C.card2, border:`1px solid ${C.border}`, borderRadius:"50%", width:36, height:36, color:C.neonText, fontSize:16, cursor:"pointer" }}>⚙️</button>
          </div>
        </div>

        {/* CONTENT */}
        <div style={{ overflowY:"auto" }}>{renderTab()}</div>

        {/* BOTTOM NAV */}
        <div style={{ position:"fixed", bottom:0, left:"50%", transform:"translateX(-50%)", width:"100%", maxWidth:420, background:C.card, borderTop:`1px solid ${C.border}`, display:"flex", zIndex:100, boxShadow:`0 -4px 30px rgba(179,71,255,0.15)` }}>
          {TABS.map((tab,i)=>(
            <button key={tab.label} onClick={()=>setActiveTab(i)} style={{ flex:1, padding:"11px 0 9px", background:"transparent", border:"none", display:"flex", flexDirection:"column", alignItems:"center", gap:3, cursor:"pointer" }}>
              <span style={{ fontSize:19 }}>{tab.icon}</span>
              <span style={{ fontSize:9, fontWeight:700, color:activeTab===i?C.neon:"#444", letterSpacing:0.2 }}>{tab.label}</span>
              {activeTab===i && <div style={{ width:16, height:3, background:C.neon, borderRadius:99, boxShadow:`0 0 8px ${C.neon}` }}/>}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
